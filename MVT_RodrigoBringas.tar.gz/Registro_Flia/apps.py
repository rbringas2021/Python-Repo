from django.apps import AppConfig


class RegistroFliaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Registro_Flia'
